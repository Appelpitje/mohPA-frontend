@echo off
title mohPA Patcher
cd /d "%~dp0"
REM Windows Store ships a fake "python.exe" stub. Always use PowerShell.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Patch-MOHPA.ps1"
echo.
pause
